package pract6;

import java.util.Scanner;

/**
 * ARTURO POLANCO CARRILLO
 * 01200720
 * 2/28/14
 */

class Cilindro {
	private static final float PI = 3.1415926535897932384626433832795f;
	private float areaBase;
	private float altura;
	private float radio;
	private float volumen;

	/*Constructors*/

	public Cilindro() {
		System.out.println("Ingrese el valor del radio del cilindro: ");
		setRadio(new Scanner(System.in).nextFloat());
		calcularArea(radio);
		System.out.println("Ingrese el valor de la altura del cilindro: ");
		setAltura(new Scanner(System.in).nextFloat());
		setVolumen(calcularVolumen(this.getAreaBase(), this.getAltura()));
	}

	public Cilindro(float radio, float altura) {
		if (radio < 0)
			radio = -radio;
		if (altura < 0)
			altura = -altura;
		setRadio(radio);
		calcularArea(radio);
		setAltura(altura);

		setVolumen(calcularVolumen(this.getAreaBase(), this.getAltura()));
	}

	public Cilindro(Cilindro cilindro) {
		this.setRadio(cilindro.getRadio());
		this.setAltura(cilindro.getAltura());
		this.setAreaBase(cilindro.getAreaBase());
		this.setVolumen(cilindro.getVolumen());
	}

	/*Setters*/

	private void setAltura(float altura) {
		if (altura < 0)
			altura = -altura;
		this.altura = altura;
	}

	private void setAreaBase(float areaBase) {
		this.areaBase = areaBase;
	}

	private void setRadio(float radio) {
		if (radio < 0)
			radio = -radio;
		this.radio = radio;
		setAreaBase(this.radio);
	}

	private void setVolumen(float volumen) {
		this.volumen = volumen;
	}

	/*Getters*/

	public float getRadio() {
		return radio;
	}

	public float getAltura() {
		return altura;
	}

	public float getAreaBase() {
		return areaBase;
	}

	public float getVolumen() {
		return volumen;
	}

	/*Calculate values*/
	private void calcularArea(float radio) {
		areaBase = (float)(PI * Math.pow(radio, 2));
	}

	private float calcularVolumen(float areaBase, float altura) {
		volumen = areaBase * altura;
		return volumen;
	}

	public String determinarCilindroMasGrande(Cilindro cilindro) {
		if (cilindro.getVolumen() > this.getVolumen())
			return "El cilindro 2 es mas grande";
		else
			if (cilindro.getVolumen()!=this.getVolumen())
				return "El cilindro 1 es mas grande";
			else
				return "Son iguales!!";
	}
}