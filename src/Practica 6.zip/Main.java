import pract6.*;

/**
 * Created by ArtofWack on 3/14/14.
 */
public class Main {
	public static void main(String[] args) {
		int[] arreglo = {1, 2, 3, 4, 5, 1, 2, 3, 4, 5};
		double[] arregloDouble = {1, 3, 4, 2, 5, 6, 24, 34.5};
		int[][] matriz = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, {1, 2, 3, 4, 35, 6, 7, 8, 9, 10}, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}};
		double[][] matrizDouble = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
				{10, 9, 8, 7, 6, 5, 4, 3, 2, 1},
				{5, 4, 3, 2, 1, 6, 7, 8, 9, 10},
				{6, 7, 8, 9, 10, 5, 4, 3, 2, 1}
		};
		NumeroComplejo numeroComplejo =  new NumeroComplejo();


		/*ControlPanel controlPanel = new ControlPanel();
		controlPanel.createButtonPanel();*/

		System.out.println("Suma de arreglo int: "+ArrayUtil.suma(arreglo));
		System.out.println("Suma de arreglos Double: "+ArrayUtil.suma(arregloDouble));
		System.out.println("suma de matriz int: "+ArrayUtil.suma(matriz));
		System.out.println("Suma de matriz double: "+ArrayUtil.suma(matrizDouble));

		System.out.println("Maximo de arreglo double: "+ArrayUtil.max(arregloDouble));
		System.out.println("Maximo de matriz double: "+ArrayUtil.max(matrizDouble));

		System.out.println("Comaprando areglo doble: "+ArrayUtil.compara(arregloDouble, ArrayUtil.arreglo));
		System.out.println("Comparando matriz doble: "+ArrayUtil.compara(matrizDouble,ArrayUtil.matriz));

		System.out.println("Sumando numero complejo tipo int: "+  numeroComplejo.getStringNumeroComplejo(numeroComplejo.sumarNumerosComplejos(3,7)));

		System.out.println("Sumando numero complejo tipo doble: "+ numeroComplejo.getStringNumeroComplejo(numeroComplejo.sumarNumerosComplejos(3.4f,7.9f)));



	}
}
